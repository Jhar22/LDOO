function myFirstFunction(){
	document.getElementById("someImage").src="src/image4.png";
}
function mySecondFunction(){
	document.getElementById("date").innerHTML=Date();
}